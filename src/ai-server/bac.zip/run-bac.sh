PORT=$1

python3 src/bac.py --port ${PORT} --folder www 

